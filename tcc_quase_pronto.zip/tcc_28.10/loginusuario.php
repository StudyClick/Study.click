<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    // Evita SQL Injection
    $nome = mysqli_real_escape_string($conexao, $nome);
    $senha = mysqli_real_escape_string($conexao, $senha);

    // Busca o usuário no banco
    $sql = "SELECT * FROM tbusuarios WHERE nome = '$nome'";
    $resultado = mysqli_query($conexao, $sql);
    
    if (mysqli_num_rows($resultado) > 0) {
        $usuario = mysqli_fetch_assoc($resultado);
        if (password_verify($senha, $usuario['senha'])) {
            session_start();
            $_SESSION['usuario'] = $usuario['nome'];
            header("Location:telainicial3.php");
            exit; 
        } else {
            echo "<script>alert('Senha incorreta.');</script>";
            echo "<script>window.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('Usuário não encontrado.');</script>";
        echo "<script>window.location.href='login.php';</script>";
    }
  }
?>

</body>
</html>