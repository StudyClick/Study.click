<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de cadastro</title>
    <link rel="stylesheet" href="estilo.css" />


    

<body>


<div class="login-card">
      <h1>Criar nova conta</h1>
      <p class="subtext">Já está cadastrado? Faça login <a href="login.php">aqui</a>.</p>

      <form class="form" action = "cadusuario.php" method = 'Post'>
        <label for="nome">Nome</label>
        <input type="text" name="nome" placeholder="Jiara Martins" />
       
        <label for="data">Data de nascimento</label>
        <input type="text" name ="data_nascimento" placeholder="0000/00/00" />


        <label for="email">Email</label>
        <input type="text" name="email" placeholder="hello@gmail.com" />

        <label for="senha">Senha</label>
        <input type="password" name="senha" placeholder="********" />

       
        <button type="submit">Cadastrar-se</button>

        
      </form>
    </div>
</head>
</body>
