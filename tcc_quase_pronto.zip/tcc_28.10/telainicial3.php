<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Ensino Fundamental 2</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #a464dc, #0d4cab );
            color: #333;
            min-height: 100vh;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Esquemas de Contraste */
        
        /* 1. Alto Contraste Preto/Branco (Para baixa visão severa) */
        body.contrast-black-white {
            background: #000000 !important;
            color: #FFFFFF !important;
        }

        body.contrast-black-white .container {
            background: #000000 !important;
            border: 3px solid #FFFFFF !important;
        }

        body.contrast-black-white .subject-card,
        body.contrast-black-white .level-card,
        body.contrast-black-white .option {
            background: #000000 !important;
            color: #FFFFFF !important;
            border: 2px solid #FFFFFF !important;
        }

        body.contrast-black-white .btn {
            background: #FFFFFF !important;
            color: #000000 !important;
            border: 2px solid #FFFFFF !important;
        }

        body.contrast-black-white .correct {
            color: #00FF00 !important;
            font-weight: bold;
        }

        body.contrast-black-white .wrong {
            color: #FF0000 !important;
            font-weight: bold;
        }

        body.contrast-black-white .option.correct {
            background: #003300 !important;
            border-color: #00FF00 !important;
            color: #FFFFFF !important;
        }

        body.contrast-black-white .option.incorrect {
            background: #330000 !important;
            border-color: #FF0000 !important;
            color: #FFFFFF !important;
        }

        /* 2. Contraste Amarelo/Preto (Para fotossensibilidade) */
        body.contrast-yellow-black {
            background: #000000 !important;
            color: #FFFF00 !important;
        }

        body.contrast-yellow-black .container {
            background: #000000 !important;
            border: 3px solid #FFFF00 !important;
        }

        body.contrast-yellow-black .subject-card,
        body.contrast-yellow-black .level-card,
        body.contrast-yellow-black .option {
            background: #000000 !important;
            color: #FFFF00 !important;
            border: 2px solid #FFFF00 !important;
        }

        body.contrast-yellow-black .btn {
            background: #FFFF00 !important;
            color: #000000 !important;
            border: 2px solid #FFFF00 !important;
        }

        body.contrast-yellow-black .correct {
            color: #00FF00 !important;
            font-weight: bold;
        }

        body.contrast-yellow-black .wrong {
            color: #FF0000 !important;
            font-weight: bold;
        }

        body.contrast-yellow-black .option.correct {
            background: #003300 !important;
            border-color: #00FF00 !important;
            color: #FFFFFF !important;
        }

        body.contrast-yellow-black .option.incorrect {
            background: #330000 !important;
            border-color: #FF0000 !important;
            color: #FFFFFF !important;
        }

        /* 3. Contraste Azul/Branco (Para daltonismo - Tritanopia) */
        body.contrast-blue-white {
            background: #000080 !important;
            color: #FFFFFF !important;
        }

        body.contrast-blue-white .container {
            background: #000080 !important;
            border: 3px solid #FFFFFF !important;
        }

        body.contrast-blue-white .subject-card,
        body.contrast-blue-white .level-card,
        body.contrast-blue-white .option {
            background: #000080 !important;
            color: #FFFFFF !important;
            border: 2px solid #FFFFFF !important;
        }

        body.contrast-blue-white .btn {
            background: #FFFFFF !important;
            color: #000080 !important;
            border: 2px solid #FFFFFF !important;
        }

        body.contrast-blue-white .correct {
            color: #00FFFF !important;
            font-weight: bold;
        }

        body.contrast-blue-white .wrong {
            color: #FF69B4 !important;
            font-weight: bold;
        }

        body.contrast-blue-white .option.correct {
            background: #004d4d !important;
            border-color: #00FFFF !important;
            color: #FFFFFF !important;
        }

        body.contrast-blue-white .option.incorrect {
            background: #4d004d !important;
            border-color: #FF69B4 !important;
            color: #FFFFFF !important;
        }

        /* 4. Modo Escuro Suave (Para sensibilidade à luz) */
        body.contrast-dark-mode {
            background: #1a1a1a !important;
            color: #e0e0e0 !important;
        }

        body.contrast-dark-mode .container {
            background: #2d2d2d !important;
            border: 2px solid #555 !important;
        }

        body.contrast-dark-mode .subject-card,
        body.contrast-dark-mode .level-card,
        body.contrast-dark-mode .option {
            background: #2d2d2d !important;
            color: #e0e0e0 !important;
            border: 2px solid #555 !important;
        }

        body.contrast-dark-mode .btn {
            background: #4FC3F7 !important;
            color: #000000 !important;
            border: 2px solid #4FC3F7 !important;
        }

        body.contrast-dark-mode .correct {
            color: #81C784 !important;
            font-weight: bold;
        }

        body.contrast-dark-mode .wrong {
            color: #E57373 !important;
            font-weight: bold;
        }

        body.contrast-dark-mode .option.correct {
            background: #1b5e20 !important;
            border-color: #81C784 !important;
            color: #FFFFFF !important;
        }

        body.contrast-dark-mode .option.incorrect {
            background: #b71c1c !important;
            border-color: #E57373 !important;
            color: #FFFFFF !important;
        }

        /* Tamanhos de fonte */
        body.font-small {
            font-size: 14px;
        }

        body.font-medium {
            font-size: 18px;
        }

        body.font-large {
            font-size: 22px;
        }

        body.font-xlarge {
            font-size: 26px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        header {
            background: linear-gradient(135deg, #a464dc, #0d4cab );
            color: white;
            padding: 20px;
            text-align: center;
            position: relative;
        }

        .contrast-black-white header,
        .contrast-yellow-black header,
        .contrast-blue-white header,
        .contrast-dark-mode header {
            background: #000000 !important;
            border-bottom: 3px solid #FFFFFF;
        }

        .contrast-yellow-black header {
            border-bottom-color: #FFFF00;
        }

        .contrast-blue-white header {
            border-bottom-color: #FFFFFF;
        }

        .contrast-dark-mode header {
            background: #1a1a1a !important;
            border-bottom-color: #555;
        }

        .accessibility-panel {
            position: absolute;
            top: 10px;
            right: 10px;
            display: flex;
            gap: 10px;
        }

        .accessibility-btn {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid white;
            color: white;
            padding: 8px 12px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .accessibility-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.05);
        }
        
        h1 {
            font-size: 2.2rem;
            margin-bottom: 10px;
        }
        
        .subtitle {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .content {
            padding: 30px;
        }
        
        .screen {
            display: none;
        }
        
        .active {
            display: block;
        }
        
        .subject-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .subject-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            border: 2px solid transparent;
        }
        
        .subject-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            border-color: #1a8cff;
        }
        
        .subject-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .contrast-black-white .subject-icon,
        .contrast-yellow-black .subject-icon,
        .contrast-blue-white .subject-icon,
        .contrast-dark-mode .subject-icon {
            color: #FFFFFF !important;
        }

        .contrast-yellow-black .subject-icon {
            color: #FFFF00 !important;
        }
        
        .level-selector {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        
        .level-card {
            flex: 1;
            margin: 0 10px;
            background: white;
            border-radius: 10px;
            padding: 25px 15px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            border: 2px solid transparent;
        }
        
        .level-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }
        
        .level-1 {
            border-color: #4CAF50;
        }
        
        .level-2 {
            border-color: #FF9800;
        }
        
        .level-3 {
            border-color: #F44336;
        }
        
        .level-title {
            font-size: 1.3rem;
            margin-bottom: 10px;
        }
        
        .level-desc {
            font-size: 0.9rem;
            color: #666;
        }

        .contrast-black-white .level-desc,
        .contrast-yellow-black .level-desc,
        .contrast-blue-white .level-desc {
            color: #FFFFFF !important;
        }

        .contrast-dark-mode .level-desc {
            color: #b0b0b0 !important;
        }
        
        .question-container {
            margin-bottom: 30px;
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            align-items: center;
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e0e0e0;
            border-radius: 4px;
            margin-bottom: 20px;
            overflow: hidden;
        }

        .contrast-black-white .progress-bar,
        .contrast-yellow-black .progress-bar,
        .contrast-blue-white .progress-bar {
            background-color: #333 !important;
        }

        .contrast-dark-mode .progress-bar {
            background-color: #555 !important;
        }
        
        .progress {
            height: 100%;
            background: linear-gradient(to right, #4CAF50, #8BC34A);
            width: 0%;
            transition: width 0.5s;
        }

        .contrast-black-white .progress,
        .contrast-yellow-black .progress {
            background: #00FF00 !important;
        }

        .contrast-blue-white .progress {
            background: #00FFFF !important;
        }

        .contrast-dark-mode .progress {
            background: #81C784 !important;
        }
        
        .question-text {
            font-size: 1.3rem;
            margin-bottom: 25px;
            line-height: 1.5;
        }
        
        .options-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .option {
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            position: relative;
            overflow: hidden;
        }
        
        .option:hover {
            background-color: #e8e8e8;
            transform: translateY(-2px);
        }
        
        .option.selected {
            border-color: #1a8cff;
            background-color: #e3f2fd;
        }
        
        .option.correct {
            background-color: #4CAF50 !important;
            color: white;
            border-color: #388E3C;
        }
        
        .option.incorrect {
            background-color: #F44336 !important;
            color: white;
            border-color: #D32F2F;
        }
        
        .option.correct::after {
            content: " ✓";
            font-weight: bold;
            position: absolute;
            right: 15px;
        }
        
        .option.incorrect::after {
            content: " ✗";
            font-weight: bold;
            position: absolute;
            right: 15px;
        }
        
        .timer {
            font-size: 1.1rem;
            font-weight: bold;
            color: #1a8cff;
            padding: 8px 15px;
            background: #E3F2FD;
            border-radius: 25px;
            border: 2px solid #1a8cff;
            min-width: 100px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .timer.warning {
            background: #FFF3CD;
            color: #856404;
            border-color: #FFC107;
            animation: pulse 1s infinite;
        }

        .timer.danger {
            background: #F8D7DA;
            color: #721C24;
            border-color: #DC3545;
            animation: pulse 0.5s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .contrast-black-white .timer,
        .contrast-yellow-black .timer,
        .contrast-blue-white .timer {
            background: #333 !important;
            color: #FFFFFF !important;
            border-color: #FFFFFF !important;
        }

        .contrast-yellow-black .timer {
            color: #FFFF00 !important;
            border-color: #FFFF00 !important;
        }

        .contrast-black-white .timer.warning,
        .contrast-yellow-black .timer.warning,
        .contrast-blue-white .timer.warning {
            background: #333 !important;
            color: #FFFF00 !important;
            border-color: #FFFF00 !important;
        }

        .contrast-black-white .timer.danger,
        .contrast-yellow-black .timer.danger,
        .contrast-blue-white .timer.danger {
            background: #333 !important;
            color: #FF0000 !important;
            border-color: #FF0000 !important;
        }

        .contrast-dark-mode .timer {
            background: #555 !important;
            color: #e0e0e0 !important;
            border-color: #4FC3F7 !important;
        }

        .contrast-dark-mode .timer.warning {
            background: #5d4037 !important;
            color: #FFD54F !important;
            border-color: #FFD54F !important;
        }

        .contrast-dark-mode .timer.danger {
            background: #4a235a !important;
            color: #E57373 !important;
            border-color: #E57373 !important;
        }
        
        .btn {
            padding: 12px 25px;
            background: linear-gradient(to right, #1a8cff, #00cc99);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 10px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-next {
            float: right;
        }

        .btn-back {
            background: linear-gradient(to right, #1a8cff, #00cc99) !important;
            margin-right: 10px;
        }
        
        .result-container {
            text-align: center;
            padding: 30px;
        }
        
        .score-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a8cff, #00cc99);
            margin: 0 auto 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .contrast-black-white .score-circle,
        .contrast-yellow-black .score-circle,
        .contrast-blue-white .score-circle {
            background: #000000 !important;
            border: 3px solid #FFFFFF;
            color: #FFFFFF !important;
        }

        .contrast-yellow-black .score-circle {
            border-color: #FFFF00;
            color: #FFFF00 !important;
        }

        .contrast-dark-mode .score-circle {
            background: #2d2d2d !important;
            border: 2px solid #555;
        }
        
        .result-message {
            font-size: 1.5rem;
            margin-bottom: 20px;
        }
        
        .result-details {
            margin-bottom: 30px;
            font-size: 1.1rem;
        }
        
        .correct {
            color: #4CAF50;
        }
        
        .wrong {
            color: #F44336;
        }
        
        /* Estilos inclusivos */
        .inclusive-message {
            background: linear-gradient(135deg, #FFD700, #FF6B6B);
            color: #333;
            padding: 15px;
            border-radius: 10px;
            margin-top: 25px;
            text-align: center;
            border: 2px solid #FF6B6B;
            box-shadow: 0 4px 8px rgba(255, 107, 107, 0.2);
        }

        .contrast-black-white .inclusive-message,
        .contrast-yellow-black .inclusive-message,
        .contrast-blue-white .inclusive-message {
            background: #000000 !important;
            border: 2px solid #FFFFFF;
            color: #FFFFFF !important;
        }

        .contrast-yellow-black .inclusive-message {
            border-color: #FFFF00;
            color: #FFFF00 !important;
        }

        .contrast-dark-mode .inclusive-message {
            background: #2d2d2d !important;
            border: 2px solid #555;
            color: #e0e0e0 !important;
        }
        
        .inclusive-message p {
            margin: 0;
            font-weight: 600;
        }
        
        .encouragement-message {
            background-color: #E3F2FD;
            color: #1565C0;
            padding: 12px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
            border-left: 4px solid #2196F3;
        }

        .contrast-black-white .encouragement-message,
        .contrast-yellow-black .encouragement-message,
        .contrast-blue-white .encouragement-message {
            background: #333 !important;
            border-left: 4px solid #FFFFFF;
            color: #FFFFFF !important;
        }

        .contrast-yellow-black .encouragement-message {
            border-left-color: #FFFF00;
            color: #FFFF00 !important;
        }

        .contrast-dark-mode .encouragement-message {
            background: #555 !important;
            border-left: 4px solid #4FC3F7;
            color: #e0e0e0 !important;
        }
        
        .encouragement-message p {
            margin: 0;
            font-weight: 500;
        }
        
        .inclusive-celebration {
            background: linear-gradient(135deg, #4CAF50, #8BC34A);
            color: white;
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }

        .contrast-black-white .inclusive-celebration,
        .contrast-yellow-black .inclusive-celebration,
        .contrast-blue-white .inclusive-celebration {
            background: #000000 !important;
            border: 2px solid #FFFFFF;
            color: #FFFFFF !important;
        }

        .contrast-yellow-black .inclusive-celebration {
            border-color: #FFFF00;
            color: #FFFF00 !important;
        }

        .contrast-dark-mode .inclusive-celebration {
            background: #2d2d2d !important;
            border: 2px solid #555;
            color: #e0e0e0 !important;
        }
        
        .inclusive-celebration p {
            margin: 0;
            font-weight: 600;
        }
        
        .inclusive-footer {
            background: linear-gradient(135deg, #666, #333);
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 20px;
        }

        .contrast-black-white .inclusive-footer,
        .contrast-yellow-black .inclusive-footer,
        .contrast-blue-white .inclusive-footer {
            background: #000000 !important;
            border-top: 3px solid #FFFFFF;
        }

        .contrast-yellow-black .inclusive-footer {
            border-top-color: #FFFF00;
        }

        .contrast-dark-mode .inclusive-footer {
            background: #1a1a1a !important;
            border-top: 2px solid #555;
        }
        
        .inclusive-footer p {
            margin: 0;
            font-size: 0.9rem;
        }

        /* Acessibilidade Visual */
        .accessibility-features {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            border: 2px solid #4FC3F7;
        }

        .contrast-black-white .accessibility-features,
        .contrast-yellow-black .accessibility-features,
        .contrast-blue-white .accessibility-features {
            background: #000000 !important;
            border: 2px solid #FFFFFF;
        }

        .contrast-yellow-black .accessibility-features {
            border-color: #FFFF00;
        }

        .contrast-dark-mode .accessibility-features {
            background: #2d2d2d !important;
            border: 2px solid #555;
        }

        .accessibility-title {
            font-size: 1.2rem;
            margin-bottom: 15px;
            color: #1565C0;
            font-weight: 600;
        }

        .contrast-black-white .accessibility-title,
        .contrast-yellow-black .accessibility-title,
        .contrast-blue-white .accessibility-title {
            color: #FFFFFF !important;
        }

        .contrast-yellow-black .accessibility-title {
            color: #FFFF00 !important;
        }

        .contrast-dark-mode .accessibility-title {
            color: #4FC3F7 !important;
        }

        .font-size-controls {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            align-items: center;
        }

        .font-btn {
            padding: 8px 15px;
            background: #4FC3F7;
            color: white;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .font-btn:hover {
            background: #039BE5;
        }

        .font-btn.active {
            background: #1565C0;
        }

        .contrast-controls {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }

        .contrast-option {
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }

        .contrast-option:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .contrast-option.active {
            border-color: #1565C0;
            background: #E3F2FD;
        }

        .contrast-preview {
            width: 100%;
            height: 40px;
            border-radius: 4px;
            margin-bottom: 8px;
            border: 1px solid #ccc;
        }

        .preview-normal { background: linear-gradient(135deg, #1a8cff, #00cc99); }
        .preview-black-white { background: #000000; border: 2px solid #FFFFFF; }
        .preview-yellow-black { background: #000000; border: 2px solid #FFFF00; }
        .preview-blue-white { background: #000080; border: 2px solid #FFFFFF; }
        .preview-dark { background: #2d2d2d; border: 2px solid #555; }

        .contrast-label {
            font-weight: 600;
            font-size: 0.9rem;
        }

        .contrast-desc {
            font-size: 0.8rem;
            color: #666;
            margin-top: 4px;
        }

        .contrast-black-white .contrast-desc,
        .contrast-yellow-black .contrast-desc,
        .contrast-blue-white .contrast-desc {
            color: #FFFFFF !important;
        }

        .contrast-dark-mode .contrast-desc {
            color: #b0b0b0 !important;
        }

        /* Melhorias de acessibilidade */
        .btn:focus,
        .option:focus,
        .subject-card:focus,
        .level-card:focus,
        .font-btn:focus,
        .contrast-option:focus {
            outline: 3px solid #FFD700;
            outline-offset: 2px;
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
        
        /* Responsividade */
        @media (max-width: 768px) {
            .subject-grid {
                grid-template-columns: 1fr 1fr;
            }
            
            .level-selector {
                flex-direction: column;
                gap: 15px;
            }
            
            .level-card {
                margin: 0;
            }
            
            .question-header {
                flex-direction: column;
                gap: 10px;
            }

            .accessibility-panel {
                position: relative;
                top: 0;
                right: 0;
                justify-content: center;
                margin-bottom: 15px;
            }

            .contrast-controls {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .subject-grid {
                grid-template-columns: 1fr;
            }
            
            .font-size-controls,
            .contrast-controls {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="accessibility-panel">
                <button class="accessibility-btn" id="contrast-toggle" title="Alternar Contraste">
                    🌙 Contraste
                </button>
                <button class="accessibility-btn" id="read-mode-btn" title="Modo Leitura">
                    📖 Leitura
                </button>
            </div>
            <h1>Quiz Ensino Fundamental 2</h1>
            <p class="subtitle">Teste seus conhecimentos em diferentes matérias de forma inclusiva</p>
        </header>
        
        <div class="content">
            <!-- Tela de seleção de matéria -->
            <div id="subject-screen" class="screen active">
                <h2>Escolha uma Matéria</h2>
                <p>Selecione a matéria que você quer testar seus conhecimentos:</p>
                
                <div class="subject-grid">
                    <div class="subject-card" data-subject="matematica">
                        <div class="subject-icon">∫</div>
                        <h3>Matemática</h3>
                    </div>
                    <div class="subject-card" data-subject="portugues">
                        <div class="subject-icon">📚</div>
                        <h3>Português</h3>
                    </div>
                    <div class="subject-card" data-subject="historia">
                        <div class="subject-icon">🏛️</div>
                        <h3>História</h3>
                    </div>
                    <div class="subject-card" data-subject="geografia">
                        <div class="subject-icon">🌎</div>
                        <h3>Geografia</h3>
                    </div>
                    <div class="subject-card" data-subject="ciencias">
                        <div class="subject-icon">🔬</div>
                        <h3>Ciências</h3>
                    </div>
                    <div class="subject-card" data-subject="ingles">
                        <div class="subject-icon">🔠</div>
                        <h3>Inglês</h3>
                    </div>
                </div>

                <!-- Painel de Acessibilidade Expandido -->
                <div class="accessibility-features">
                    <div class="accessibility-title">👁️ Configurações de Acessibilidade Visual</div>
                    
                    <div class="font-size-controls">
                        <span style="margin-right: 10px; font-weight: 600;">Tamanho do texto:</span>
                        <button class="font-btn" data-size="small">A-</button>
                        <button class="font-btn active" data-size="medium">A</button>
                        <button class="font-btn" data-size="large">A+</button>
                        <button class="font-btn" data-size="xlarge">A++</button>
                    </div>
                    
                    <div class="contrast-controls">
                        <div class="contrast-option active" data-contrast="normal">
                            <div class="contrast-preview preview-normal"></div>
                            <div class="contrast-label">Normal</div>
                            <div class="contrast-desc">Cores originais do site</div>
                        </div>
                        
                        <div class="contrast-option" data-contrast="black-white">
                            <div class="contrast-preview preview-black-white"></div>
                            <div class="contrast-label">Preto/Branco</div>
                            <div class="contrast-desc">Para baixa visão severa</div>
                        </div>
                        
                        <div class="contrast-option" data-contrast="yellow-black">
                            <div class="contrast-preview preview-yellow-black"></div>
                            <div class="contrast-label">Amarelo/Preto</div>
                            <div class="contrast-desc">Para fotossensibilidade</div>
                        </div>
                        
                        <div class="contrast-option" data-contrast="blue-white">
                            <div class="contrast-preview preview-blue-white"></div>
                            <div class="contrast-label">Azul/Branco</div>
                            <div class="contrast-desc">Para daltonismo (Tritanopia)</div>
                        </div>
                        
                        <div class="contrast-option" data-contrast="dark-mode">
                            <div class="contrast-preview preview-dark"></div>
                            <div class="contrast-label">Modo Escuro</div>
                            <div class="contrast-desc">Para sensibilidade à luz</div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <!-- Tela de seleção de nível -->
            <div id="level-screen" class="screen">
                <h2>Escolha o Nível de Dificuldade</h2>
                <p>Selecione o nível que combina com você:</p>
                
                <div class="level-selector">
                    <div class="level-card level-1" data-level="1">
                        <h3 class="level-title">Nível 1</h3>
                        <p class="level-desc">Para quem está começando</p>
                    </div>
                    <div class="level-card level-2" data-level="2">
                        <h3 class="level-title">Nível 2</h3>
                        <p class="level-desc">Para quem já tem alguma prática</p>
                    </div>
                    <div class="level-card level-3" data-level="3">
                        <h3 class="level-title">Nível 3</h3>
                        <p class="level-desc">Para quem quer um desafio maior</p>
                    </div>
                </div>
                
                <button id="back-to-subjects" class="btn btn-back">← Voltar</button>
            </div>
            
            <!-- Tela de perguntas -->
            <div id="question-screen" class="screen">
                <div class="question-header">
                    <div>
                        <span id="current-subject">Matemática</span> - Nível <span id="current-level">1</span>
                    </div>
                    <div class="timer" id="timer">
                        1:30
                    </div>
                </div>
                
                <div class="progress-bar">
                    <div class="progress" id="progress-bar"></div>
                </div>
                
                <div class="question-container">
                    <h3 class="question-text" id="question-text">Pergunta aparecerá aqui</h3>
                    
                    <div class="options-container" id="options-container">
                        <!-- As opções serão inseridas aqui via JavaScript -->
                    </div>
                </div>
                
                <div class="encouragement-message">
                    <p>💪 Você tem 1 minuto e 30 segundos! Use o tempo com sabedoria.</p>
                    <p>⏰ Dica: Leia com calma e revise sua resposta antes de confirmar</p>
                </div>
                
                <button id="back-to-levels" class="btn btn-back">← Voltar</button>
                <button id="next-question" class="btn btn-next">Continuar</button>
            </div>
            
            <!-- Tela de resultados -->
            <div id="result-screen" class="screen">
                <div class="result-container">
                    <h2>Parabéns! Você completou o quiz! 🎉</h2>
                    
                    <div class="score-circle" id="score-circle">
                        0%
                    </div>
                    
                    <p class="result-message" id="result-message">Mensagem de resultado</p>
                    
                    <div class="result-details">
                        <p>Respostas corretas: <span id="correct-answers" class="correct">0</span>/<span id="total-questions">15</span></p>
                        <p>Respostas para revisar: <span id="wrong-answers" class="wrong">0</span></p>
                    </div>
                    
                    <div class="inclusive-celebration">
                        <p>🌟 <strong>Seu esforço é o que importa!</strong> Cada tentativa é uma vitória.</p>
                        <p>⏰ Agora com mais tempo para pensar e aprender!</p>
                    </div>
                    
                    <button id="back-to-subjects-final" class="btn btn-back">← Voltar ao Início</button>
                    <button id="restart-quiz" class="btn">Fazer Outro Quiz</button>
                </div>
            </div>
        </div>
        
    </div>

    <script>
        // Dados completos do quiz com todas as matérias
        const quizData = {
            matematica: {
                1: [
                    {
                        question: "Quanto é 15 + 27?",
                        options: ["40", "41", "42", "43"],
                        correct: 2
                    },
                    {
                        question: "Subtraia: 43 - 18 =",
                        options: ["25", "24", "26", "23"],
                        correct: 0
                    },
                    {
                        question: "Multiplique: 7 × 6 =",
                        options: ["36", "42", "48", "40"],
                        correct: 1
                    },
                    {
                        question: "Divida: 48 ÷ 8 =",
                        options: ["8", "6", "7", "5"],
                        correct: 1
                    },
                    {
                        question: "Quanto é 3²?",
                        options: ["6", "9", "8", "12"],
                        correct: 1
                    },
                    {
                        question: "Qual fração representa metade?",
                        options: ["1/3", "2/3", "1/2", "2/4"],
                        correct: 2
                    },
                    {
                        question: "Qual é o dobro de 35?",
                        options: ["60", "65", "70", "75"],
                        correct: 2
                    },
                    {
                        question: "Qual número é maior: 0,5 ou 0,75?",
                        options: ["0,5", "0,6", "0,75", "São iguais"],
                        correct: 2
                    },
                    {
                        question: "Resolva: 5 + 3 × 2 =",
                        options: ["11", "16", "10", "8"],
                        correct: 0
                    },
                    {
                        question: "O que é um número primo?",
                        options: ["Todo número par", "Número divisível apenas por 1 e ele mesmo", "Número que termina em 5", "Número negativo"],
                        correct: 1
                    },
                    {
                        question: "Qual é a metade de 80?",
                        options: ["30", "35", "40", "45"],
                        correct: 2
                    },
                    {
                        question: "Qual é a unidade do número 123?",
                        options: ["1", "2", "3", "12"],
                        correct: 2
                    },
                    {
                        question: "Converta 2000 metros em quilômetros.",
                        options: ["0,2 km", "2 km", "20 km", "200 km"],
                        correct: 1
                    },
                    {
                        question: "Quanto é 10³?",
                        options: ["30", "100", "1000", "300"],
                        correct: 2
                    },
                    {
                        question: "Escreva o número 254 em palavras.",
                        options: ["Duzentos e cinquenta e quatro", "Duzentos e quarenta e cinco", "Duzentos e cinquenta", "Duzentos e sessenta e quatro"],
                        correct: 0
                    }
                ],
                2: [
                    {
                        question: "Resolva: 2x + 5 = 13",
                        options: ["x = 3", "x = 4", "x = 5", "x = 2"],
                        correct: 1
                    },
                    {
                        question: "Qual é a média entre 12, 15 e 18?",
                        options: ["14", "15", "16", "17"],
                        correct: 1
                    },
                    {
                        question: "Transforme 0,75 em fração.",
                        options: ["¾", "½", "⅔", "¼"],
                        correct: 0
                    },
                    {
                        question: "Qual é o perímetro de um quadrado de lado 6 cm?",
                        options: ["12 cm", "18 cm", "24 cm", "36 cm"],
                        correct: 2
                    },
                    {
                        question: "Qual é a área de um triângulo com base 8 cm e altura 5 cm?",
                        options: ["20 cm²", "30 cm²", "40 cm²", "50 cm²"],
                        correct: 0
                    },
                    {
                        question: "Resolva: 3(x - 2) = 9",
                        options: ["x = 2", "x = 3", "x = 4", "x = 5"],
                        correct: 3
                    },
                    {
                        question: "Converta 3/4 em porcentagem.",
                        options: ["25%", "50%", "75%", "100%"],
                        correct: 2
                    },
                    {
                        question: "Qual é o valor de x em 5x = 35?",
                        options: ["6", "7", "8", "9"],
                        correct: 1
                    },
                    {
                        question: "Resolva: 12 ÷ 0,5",
                        options: ["6", "18", "20", "24"],
                        correct: 3
                    },
                    {
                        question: "Qual é a diferença entre ângulo agudo e obtuso?",
                        options: ["Agudo < 90°, obtuso > 90°", "Agudo > 90°, obtuso < 90°", "Ambos são 90°", "Nenhum tem medida"],
                        correct: 0
                    },
                    {
                        question: "Resolva: 7² - 10 =",
                        options: ["39", "40", "41", "49"],
                        correct: 0
                    },
                    {
                        question: "O que é um número racional?",
                        options: ["Número que não pode ser escrito como fração", "Número que pode ser escrito como fração", "Número primo", "Número ímpar"],
                        correct: 1
                    },
                    {
                        question: "Qual é a raiz quadrada de 144?",
                        options: ["10", "11", "12", "14"],
                        correct: 2
                    },
                    {
                        question: "Converta 2500 g em kg.",
                        options: ["0,25 kg", "2,5 kg", "25 kg", "250 kg"],
                        correct: 1
                    },
                    {
                        question: "Resolva: 2x - 7 = 9",
                        options: ["x = 7", "x = 8", "x = 9", "x = 10"],
                        correct: 1
                    }
                ],
                3: [
                    {
                        question: "Resolva: 3x + 5 = 2x + 12",
                        options: ["x = 5", "x = 6", "x = 7", "x = 8"],
                        correct: 2
                    },
                    {
                        question: "Calcule a área de um círculo com raio 7 cm (π ≈ 3,14).",
                        options: ["120 cm²", "145 cm²", "154 cm²", "160 cm²"],
                        correct: 2
                    },
                    {
                        question: "Resolva: 2x² - 8x + 6 = 0",
                        options: ["x = 1 e x = 2", "x = 2 e x = 3", "x = 1,5 e x = 2", "x = 3 e x = 4"],
                        correct: 0
                    },
                    {
                        question: "Quanto é 2³ × 2²?",
                        options: ["8", "12", "16", "32"],
                        correct: 3
                    },
                    {
                        question: "Converta 0,625 em fração simplificada.",
                        options: ["¼", "⅓", "⅝", "5/8"],
                        correct: 3
                    },
                    {
                        question: "Qual é a diferença entre número irracional e racional?",
                        options: ["Racional é exato; irracional é infinito e não periódico", "Irracional é inteiro; racional é fracionário", "Ambos são iguais", "Nenhum é número real"],
                        correct: 0
                    },
                    {
                        question: "Resolva: (5x - 3)/2 = 4",
                        options: ["x = 2", "x = 3", "x = 4", "x = 5"],
                        correct: 1
                    },
                    {
                        question: "Determine o volume de um cubo com lado 5 cm.",
                        options: ["25 cm³", "50 cm³", "100 cm³", "125 cm³"],
                        correct: 3
                    },
                    {
                        question: "Resolva: √81 + 2² =",
                        options: ["10", "11", "13", "12"],
                        correct: 2
                    },
                    {
                        question: "Resolva: 3/4 + 5/6",
                        options: ["1", "1,25", "1,5", "1,55"],
                        correct: 1
                    },
                    {
                        question: "Identifique o coeficiente em 7x² - 5x + 3.",
                        options: ["7", "-5", "3", "x"],
                        correct: 0
                    },
                    {
                        question: "Qual é a soma dos ângulos internos de um hexágono?",
                        options: ["360°", "540°", "720°", "900°"],
                        correct: 2
                    },
                    {
                        question: "Resolva: 4x - 7 = 2x + 5",
                        options: ["x = 3", "x = 4", "x = 5", "x = 6"],
                        correct: 3
                    },
                    {
                        question: "Calcule a hipotenusa de um triângulo com catetos 3 cm e 4 cm.",
                        options: ["5 cm", "6 cm", "7 cm", "8 cm"],
                        correct: 0
                    },
                    {
                        question: "Resolva: 5² - (3 × 4) + 6",
                        options: ["19", "20", "21", "22"],
                        correct: 0
                    }
                ]
            },
            portugues: {
                1: [
                    {
                        question: "Qual é a função do sujeito em uma frase?",
                        options: ["Indicar a ação", "Indicar quem pratica a ação", "Indicar o objeto", "Indicar o tempo"],
                        correct: 1
                    },
                    {
                        question: "Identifique o substantivo na frase: 'O gato correu rápido.'",
                        options: ["O", "Gato", "Correu", "Rápido"],
                        correct: 1
                    },
                    {
                        question: "Qual é a diferença entre verbo e adjetivo?",
                        options: ["Verbo indica ação; adjetivo indica característica", "Verbo indica característica; adjetivo indica ação", "Ambos indicam ação", "Ambos indicam característica"],
                        correct: 0
                    },
                    {
                        question: "Transforme a frase 'Ele correu' para negativa.",
                        options: ["Ele correu não", "Ele não correu", "Não correu ele", "Não ele correu"],
                        correct: 1
                    },
                    {
                        question: "Complete: 'Eu _____ feliz.' (verbo ser)",
                        options: ["É", "Sou", "Está", "Ser"],
                        correct: 1
                    },
                    {
                        question: "O que é um artigo definido?",
                        options: ["A, o, os, as", "Um, uma", "E, ou", "Que, como"],
                        correct: 0
                    },
                    {
                        question: "Qual é o plural de 'lápis'?",
                        options: ["Lápises", "Lápis", "Lápisão", "Lápises"],
                        correct: 1
                    },
                    {
                        question: "Identifique o pronome na frase: 'Ela gosta de sorvete.'",
                        options: ["Ela", "Gosta", "Sorvete", "De"],
                        correct: 0
                    },
                    {
                        question: "Qual a função da pontuação na frase?",
                        options: ["Organizar e separar ideias", "Substituir verbos", "Indicar sujeito", "Indicar tempo"],
                        correct: 0
                    },
                    {
                        question: "Diferencie sujeito e predicado.",
                        options: ["Sujeito pratica a ação; predicado indica ação do sujeito", "Sujeito indica objeto; predicado indica característica", "Ambos indicam ação", "Ambos indicam objeto"],
                        correct: 0
                    },
                    {
                        question: "O que é um advérbio?",
                        options: ["Indica ação", "Indica característica", "Indica circunstância de tempo, modo ou lugar", "Indica sujeito"],
                        correct: 2
                    },
                    {
                        question: "Qual é o antônimo de 'feliz'?",
                        options: ["Alegre", "Triste", "Contente", "Satisfeito"],
                        correct: 1
                    },
                    {
                        question: "Transforme a frase 'Ele estudou ontem' para o presente.",
                        options: ["Ele estudou hoje", "Ele estuda", "Ele estudará", "Ele estudando"],
                        correct: 1
                    },
                    {
                        question: "Qual é a diferença entre palavra simples e composta?",
                        options: ["Simples: uma raiz; composta: duas ou mais", "Simples: duas raízes; composta: uma raiz", "Ambas têm várias raízes", "Ambas têm apenas uma raiz"],
                        correct: 0
                    },
                    {
                        question: "Identifique o verbo na frase: 'O cachorro latiu alto.'",
                        options: ["Cachorro", "Latiu", "Alto", "O"],
                        correct: 1
                    }
                ],
                2: [
                    {
                        question: "Identifique o tempo verbal da frase: 'Eles viajavam todos os verões.'",
                        options: ["Presente", "Passado", "Imperfeito", "Futuro"],
                        correct: 2
                    },
                    {
                        question: "Transforme a frase 'Ela lê livros' para negativa.",
                        options: ["Ela não lê livros", "Ela não leu livros", "Ela não está lendo livros", "Ela não leu livro"],
                        correct: 0
                    },
                    {
                        question: "Qual a diferença entre pronome pessoal e possessivo?",
                        options: ["Pessoal indica objeto; possessivo indica ação", "Pessoal indica pessoa; possessivo indica posse", "Pessoal indica ação; possessivo indica tempo", "Ambos indicam ação"],
                        correct: 1
                    },
                    {
                        question: "Reescreva a frase no plural: 'O aluno fez a prova.'",
                        options: ["Os alunos fez as provas", "Os alunos fizeram as provas", "Os alunos faz a prova", "O alunos fizeram prova"],
                        correct: 1
                    },
                    {
                        question: "O que é uma oração subordinada?",
                        options: ["Uma frase independente", "Uma frase que depende de outra para ter sentido completo", "Um verbo isolado", "Um substantivo"],
                        correct: 1
                    },
                    {
                        question: "Identifique o sujeito da frase: 'Choverá amanhã.'",
                        options: ["Amanhã", "Choverá", "O tempo", "Não há sujeito explícito"],
                        correct: 3
                    },
                    {
                        question: "Qual é a função do conector 'porém'?",
                        options: ["Indicar oposição", "Indicar tempo", "Indicar causa", "Indicar consequência"],
                        correct: 0
                    },
                    {
                        question: "Diferencie metáfora e comparação.",
                        options: ["Metáfora usa 'como'; comparação não", "Comparação usa 'como'; metáfora não", "Ambas são iguais", "Nenhuma indica semelhança"],
                        correct: 1
                    },
                    {
                        question: "Reescreva a frase usando voz passiva: 'O professor corrigiu a prova.'",
                        options: ["A prova corrigiu o professor", "A prova foi corrigida pelo professor", "O professor foi corrigido pela prova", "Corrigiu a prova o professor"],
                        correct: 1
                    },
                    {
                        question: "Identifique o advérbio na frase: 'Ele correu rapidamente.'",
                        options: ["Ele", "Correu", "Rapidamente", "Não há advérbio"],
                        correct: 2
                    },
                    {
                        question: "O que é um substantivo coletivo?",
                        options: ["Indica um grupo de seres da mesma espécie", "Indica ação", "Indica lugar", "Indica característica"],
                        correct: 0
                    },
                    {
                        question: "Transforme a frase 'Nós comemos pizza' para o futuro.",
                        options: ["Nós comeremos pizza", "Nós comemos pizza amanhã", "Nós comemos pizza sempre", "Nós comendo pizza"],
                        correct: 0
                    },
                    {
                        question: "Qual é a diferença entre narrador em primeira e terceira pessoa?",
                        options: ["Primeira pessoa: 'eu/nós'; terceira pessoa: 'ele/ela/eles'", "Primeira pessoa: 'ele/ela'; terceira pessoa: 'eu/nós'", "Ambas usam 'eu'", "Ambas usam 'eles'"],
                        correct: 0
                    },
                    {
                        question: "Identifique o verbo composto na frase: 'Ela tinha estudado bastante.'",
                        options: ["Ela", "Tinha estudado", "Bastante", "Estudado"],
                        correct: 1
                    },
                    {
                        question: "Diferencie linguagem formal e informal.",
                        options: ["Formal: culto; informal: cotidiano", "Formal: cotidiano; informal: culto", "Ambas são iguais", "Formal: escrita; informal: apenas oral"],
                        correct: 0
                    }
                ],
                3: [
                    {
                        question: "Explique a diferença entre crase e preposição.",
                        options: ["A crase é a fusão de duas vogais 'a'; a preposição é uma palavra que liga termos.", "A crase é usada sempre que há 'a'; a preposição nunca é usada.", "Ambas são a mesma coisa.", "A crase é usada apenas antes de verbo."],
                        correct: 0
                    },
                    {
                        question: "Reescreva a frase usando linguagem culta: 'Vou te ligar depois.'",
                        options: ["Ligar-te-ei mais tarde.", "Te ligar depois vou.", "Depois vou ligar você.", "Irei te ligar mais tarde."],
                        correct: 0
                    },
                    {
                        question: "Identifique o sujeito indeterminado: 'Vive-se bem aqui.'",
                        options: ["Vive-se", "Aqui", "Se", "Bem"],
                        correct: 2
                    },
                    {
                        question: "Transforme a frase ativa em passiva: 'O cientista descobriu a vacina.'",
                        options: ["A vacina foi descoberta pelo cientista.", "O cientista foi descoberto pela vacina.", "Descobriu-se a vacina pelo cientista.", "A vacina descobriu o cientista."],
                        correct: 0
                    },
                    {
                        question: "Diferencie oração coordenada e subordinada.",
                        options: ["Coordenada é independente; subordinada depende de outra.", "Subordinada é independente; coordenada depende de outra.", "Ambas são independentes.", "Nenhuma depende de outra."],
                        correct: 0
                    },
                    {
                        question: "Explique o uso do sinal de dois pontos.",
                        options: ["Introduzir explicações, falas ou enumerações.", "Indicar fim de frase.", "Indicar pausa longa.", "Substituir a vírgula."],
                        correct: 0
                    },
                    {
                        question: "Identifique a função do verbo no futuro do subjuntivo.",
                        options: ["Indicar ação certa no futuro.", "Indicar ação duvidosa ou condicional no futuro.", "Indicar ação passada.", "Indicar ação contínua."],
                        correct: 1
                    },
                    {
                        question: "Reescreva a frase no estilo indireto: 'Ele disse: 'Vou estudar'.'",
                        options: ["Ele disse que ia estudar.", "Ele disse vou estudar.", "Ele disse estudará.", "Ele falou: estudou."],
                        correct: 0
                    },
                    {
                        question: "Diferencie substantivo próprio e comum.",
                        options: ["Próprio: nomeia ser específico; comum: ser genérico.", "Próprio: nomeia objeto; comum: ação.", "Ambos são nomes de pessoas.", "Ambos indicam ações."],
                        correct: 0
                    },
                    {
                        question: "Identifique o período composto na frase: 'Fui ao parque e encontrei meus amigos.'",
                        options: ["Uma oração simples.", "Duas orações coordenadas.", "Três orações subordinadas.", "Uma oração sem verbo."],
                        correct: 1
                    },
                    {
                        question: "Explique o uso da vírgula em enumeração.",
                        options: ["Separar elementos de mesma função.", "Indicar pausa dramática.", "Substituir ponto final.", "Indicar dúvida."],
                        correct: 0
                    },
                    {
                        question: "Diferencie advérbio de intensidade e de tempo.",
                        options: ["Intensidade: indica grau; tempo: indica quando.", "Intensidade: indica lugar; tempo: indica causa.", "Ambos indicam modo.", "Nenhum indica tempo."],
                        correct: 0
                    },
                    {
                        question: "Reescreva a frase usando sinônimos: 'A menina estava feliz.'",
                        options: ["A garota estava contente.", "A moça estava triste.", "A criança estava chorando.", "A garota ficou cansada."],
                        correct: 0
                    },
                    {
                        question: "Explique o uso correto do 'por que', 'porque', 'porquê' e 'por quê'.",
                        options: ["Cada um tem uso específico conforme posição na frase.", "Todos têm o mesmo significado.", "'Por que' só se usa no início da frase.", "'Porque' só se usa em perguntas."],
                        correct: 0
                    },
                    {
                        question: "Identifique a função sintática de 'aos alunos' na frase: 'Entreguei os livros aos alunos.'",
                        options: ["Objeto indireto.", "Sujeito.", "Adj. adverbial de tempo.", "Complemento nominal."],
                        correct: 0
                    }
                ]
            },
            historia: {
                1: [
                    {
                        question: "Qual foi o primeiro grande período da história humana?",
                        options: ["Idade Média", "Idade Antiga", "Idade da Pedra", "Idade Moderna"],
                        correct: 2
                    },
                    {
                        question: "O que significa 'pré-história'?",
                        options: ["Período após a invenção da escrita", "Período antes da escrita", "Período da Revolução Industrial", "Período dos grandes impérios"],
                        correct: 1
                    },
                    {
                        question: "Em qual continente o ser humano surgiu?",
                        options: ["Ásia", "África", "Europa", "América"],
                        correct: 1
                    },
                    {
                        question: "O que marcou o fim da pré-história?",
                        options: ["Descoberta do fogo", "Invenção da escrita", "Criação da roda", "Domesticação de animais"],
                        correct: 1
                    },
                    {
                        question: "Onde surgiram as primeiras civilizações?",
                        options: ["Nas florestas", "Perto dos rios", "No deserto", "Nas montanhas"],
                        correct: 1
                    },
                    {
                        question: "Qual era o principal meio de sobrevivência dos povos paleolíticos?",
                        options: ["Agricultura", "Caça e coleta", "Comércio", "Metalurgia"],
                        correct: 1
                    },
                    {
                        question: "O que foi o Egito Antigo?",
                        options: ["Um império africano às margens do rio Nilo", "Uma cidade grega", "Uma colônia romana", "Um reino asiático"],
                        correct: 0
                    },
                    {
                        question: "O que é uma pirâmide egípcia?",
                        options: ["Um templo para os deuses", "Um túmulo para os faraós", "Um palácio", "Um mercado"],
                        correct: 1
                    },
                    {
                        question: "Qual era a principal religião do Egito Antigo?",
                        options: ["Politeísta (vários deuses)", "Monoteísta (um só deus)", "Sem religião", "Científica"],
                        correct: 0
                    },
                    {
                        question: "Qual era o nome dos governantes do Egito?",
                        options: ["Reis", "Faraós", "Imperadores", "Sacerdotes"],
                        correct: 1
                    },
                    {
                        question: "Qual foi uma importante invenção dos povos antigos?",
                        options: ["Escrita", "Automóvel", "Internet", "Relógio digital"],
                        correct: 0
                    },
                    {
                        question: "O que os gregos valorizavam muito em sua cultura?",
                        options: ["A guerra e a força", "O corpo e a mente", "O comércio marítimo", "A obediência cega"],
                        correct: 1
                    },
                    {
                        question: "Qual era a principal cidade rival de Esparta na Grécia Antiga?",
                        options: ["Roma", "Atenas", "Troia", "Delfos"],
                        correct: 1
                    },
                    {
                        question: "O que é democracia?",
                        options: ["Governo de um só", "Governo do povo", "Governo religioso", "Governo militar"],
                        correct: 1
                    },
                    {
                        question: "Quem fundou o Império Romano?",
                        options: ["Gregos", "Romanos", "Egípcios", "Fenícios"],
                        correct: 1
                    }
                ],
                2: [
                    {
                        question: "O que marcou o fim do Império Romano do Ocidente?",
                        options: ["Queda de Constantinopla", "Invasões bárbaras", "Expansão grega", "Criação da escrita"],
                        correct: 1
                    },
                    {
                        question: "Qual foi o sistema político predominante na Idade Média?",
                        options: ["Capitalismo", "Feudalismo", "Socialismo", "Absolutismo"],
                        correct: 1
                    },
                    {
                        question: "Qual era a principal função dos servos no feudalismo?",
                        options: ["Governar os reinos", "Cultivar as terras", "Liderar exércitos", "Cuidar das igrejas"],
                        correct: 1
                    },
                    {
                        question: "O que foi a Igreja Católica na Idade Média?",
                        options: ["Uma instituição com pouco poder", "A maior autoridade espiritual e política da Europa", "Um grupo de comerciantes", "Uma seita secreta"],
                        correct: 1
                    },
                    {
                        question: "O que foram as Cruzadas?",
                        options: ["Viagens religiosas para conquistar Jerusalém", "Revoltas camponesas", "Expedições científicas", "Invasões vikings"],
                        correct: 0
                    },
                    {
                        question: "Qual evento marcou o início da Idade Moderna?",
                        options: ["Revolução Industrial", "Queda de Constantinopla", "Independência dos EUA", "Guerra dos Cem Anos"],
                        correct: 1
                    },
                    {
                        question: "O que foi o Renascimento Cultural?",
                        options: ["Um movimento artístico e científico da Idade Moderna", "Um novo sistema político", "Um período de guerras", "Um movimento religioso"],
                        correct: 0
                    },
                    {
                        question: "Qual invenção ajudou na difusão do conhecimento nesse período?",
                        options: ["Imprensa", "Rádio", "Telégrafo", "Internet"],
                        correct: 0
                    },
                    {
                        question: "Quem foi Cristóvão Colombo?",
                        options: ["Explorador que chegou à América em 1492", "Rei de Portugal", "Imperador romano", "Cientista grego"],
                        correct: 0
                    },
                    {
                        question: "O que foi o absolutismo?",
                        options: ["Poder total concentrado nas mãos do rei", "Divisão de poderes", "Governo do povo", "Democracia plena"],
                        correct: 0
                    },
                    {
                        question: "O que foi a Reforma Protestante?",
                        options: ["Movimento contra a Igreja Católica liderado por Martinho Lutero", "Expansão marítima", "Movimento artístico", "Invenção da imprensa"],
                        correct: 0
                    },
                    {
                        question: "O que motivou as grandes navegações europeias?",
                        options: ["Busca por novas rotas comerciais", "Fome e guerras internas", "Desejo de aventuras", "Perseguição religiosa"],
                        correct: 0
                    },
                    {
                        question: "Quem dominava o Brasil antes da chegada dos portugueses?",
                        options: ["Povos indígenas", "Espanhóis", "Ingleses", "Franceses"],
                        correct: 0
                    },
                    {
                        question: "Em que ano o Brasil foi 'descoberto'?",
                        options: ["1492", "1500", "1550", "1600"],
                        correct: 1
                    },
                    {
                        question: "Quem era o rei de Portugal quando o Brasil foi descoberto?",
                        options: ["Dom Pedro I", "Dom Manuel", "Dom João VI", "Dom Henrique"],
                        correct: 1
                    }
                ],
                3: [
                    {
                        question: "O que foi o Iluminismo?",
                        options: ["Movimento filosófico que defendia a razão e a liberdade", "Expansão colonial europeia", "Revolução religiosa", "Ideia absolutista"],
                        correct: 0
                    },
                    {
                        question: "O que foi a Revolução Francesa?",
                        options: ["Luta do povo francês contra o absolutismo", "Guerra entre França e Inglaterra", "Expansão colonial", "Movimento artístico"],
                        correct: 0
                    },
                    {
                        question: "O que representava o lema 'Liberdade, Igualdade e Fraternidade'?",
                        options: ["Ideais da Revolução Francesa", "Leis da Igreja", "Ordens militares", "Ideias feudais"],
                        correct: 0
                    },
                    {
                        question: "O que foi a Independência do Brasil?",
                        options: ["Separação política de Portugal", "Fim da escravidão", "Chegada dos portugueses", "Proclamação da República"],
                        correct: 0
                    },
                    {
                        question: "Quem proclamou a Independência do Brasil?",
                        options: ["Dom Pedro I", "Dom João VI", "José Bonifácio", "Tiradentes"],
                        correct: 0
                    },
                    {
                        question: "Em que ano foi proclamada a Independência do Brasil?",
                        options: ["1500", "1822", "1889", "1922"],
                        correct: 1
                    },
                    {
                        question: "O que foi a Revolução Industrial?",
                        options: ["Substituição do trabalho manual pelas máquinas", "Invenção da agricultura", "Expansão marítima", "Guerra entre potências europeias"],
                        correct: 0
                    },
                    {
                        question: "Em qual país começou a Revolução Industrial?",
                        options: ["França", "Inglaterra", "Alemanha", "Itália"],
                        correct: 1
                    },
                    {
                        question: "O que foi a escravidão no Brasil?",
                        options: ["Sistema de trabalho forçado de africanos e indígenas", "Comércio entre países", "Período republicano", "Movimento religioso"],
                        correct: 0
                    },
                    {
                        question: "Quem foi Tiradentes?",
                        options: ["Líder da Inconfidência Mineira", "Rei de Portugal", "Escravo alforriado", "Padre político"],
                        correct: 0
                    },
                    {
                        question: "O que marcou o fim da monarquia no Brasil?",
                        options: ["Proclamação da República", "Independência", "Abolição da escravidão", "Golpe militar"],
                        correct: 0
                    },
                    {
                        question: "Quem foi o primeiro presidente do Brasil?",
                        options: ["Getúlio Vargas", "Marechal Deodoro da Fonseca", "Dom Pedro II", "Juscelino Kubitschek"],
                        correct: 1
                    },
                    {
                        question: "Quando ocorreu a abolição da escravidão no Brasil?",
                        options: ["1822", "1888", "1889", "1900"],
                        correct: 1
                    },
                    {
                        question: "Quem assinou a Lei Áurea?",
                        options: ["Princesa Isabel", "Dom Pedro II", "José do Patrocínio", "Joaquim Nabuco"],
                        correct: 0
                    },
                    {
                        question: "O que foi a Segunda Guerra Mundial?",
                        options: ["Conflito global entre 1939 e 1945", "Guerra entre Portugal e Brasil", "Revolta no Egito Antigo", "Luta religiosa medieval"],
                        correct: 0
                    }
                ]
            },
            geografia: {
                1: [
                    {
                        question: "O que é continente?",
                        options: ["Uma ilha", "Uma grande massa de terra contínua", "Um país", "Um rio"],
                        correct: 1
                    },
                    {
                        question: "Qual é o maior continente do mundo?",
                        options: ["África", "Ásia", "Europa", "América"],
                        correct: 1
                    },
                    {
                        question: "Qual é o continente onde está o Brasil?",
                        options: ["América do Norte", "América do Sul", "Europa", "África"],
                        correct: 1
                    },
                    {
                        question: "O que é oceano?",
                        options: ["Um lago grande", "Uma grande massa de água salgada", "Um rio", "Uma ilha"],
                        correct: 1
                    },
                    {
                        question: "Qual é o maior oceano do mundo?",
                        options: ["Atlântico", "Índico", "Pacífico", "Ártico"],
                        correct: 2
                    },
                    {
                        question: "O que são mapas?",
                        options: ["Fotografias da Terra", "Representações gráficas do espaço geográfico", "Desenhos de animais", "Livros de história"],
                        correct: 1
                    },
                    {
                        question: "O que é latitude?",
                        options: ["Distância entre o Norte e o Sul", "Distância entre o Leste e o Oeste", "Altura de montanhas", "Profundidade do oceano"],
                        correct: 0
                    },
                    {
                        question: "O que é longitude?",
                        options: ["Distância entre o Norte e o Sul", "Distância entre o Leste e o Oeste", "Altura de montanhas", "Profundidade do oceano"],
                        correct: 1
                    },
                    {
                        question: "O que é clima?",
                        options: ["Tipo de solo", "Condições atmosféricas de uma região", "Tipo de relevo", "Vegetação de uma região"],
                        correct: 1
                    },
                    {
                        question: "Qual é a principal característica do clima tropical?",
                        options: ["Frio intenso", "Quente e úmido", "Árido", "Polar"],
                        correct: 1
                    },
                    {
                        question: "O que são recursos naturais?",
                        options: ["Produtos industrializados", "Elementos da natureza usados pelo ser humano", "Construções humanas", "Animais domésticos"],
                        correct: 1
                    },
                    {
                        question: "O que é relevo?",
                        options: ["Superfície da Terra com diferentes formas", "Temperatura média de um lugar", "Tipo de vegetação", "Quantidade de rios"],
                        correct: 0
                    },
                    {
                        question: "O que é vegetação?",
                        options: ["Conjunto de rios", "Conjunto de plantas que cresce naturalmente em uma região", "Tipo de solo", "Montanhas"],
                        correct: 1
                    },
                    {
                        question: "O que é população?",
                        options: ["Conjunto de animais de uma região", "Conjunto de pessoas que vivem em uma área", "Número de árvores", "Número de rios"],
                        correct: 1
                    },
                    {
                        question: "O que é urbanização?",
                        options: ["Crescimento das cidades", "Formação de rios", "Crescimento de florestas", "Formação de montanhas"],
                        correct: 0
                    }
                ],
                2: [
                    {
                        question: "O que é globalização?",
                        options: ["Isolamento econômico", "Integração econômica, cultural e política entre países", "Formação de continentes", "Crescimento das cidades"],
                        correct: 1
                    },
                    {
                        question: "Qual é a principal consequência da urbanização acelerada?",
                        options: ["Redução da população urbana", "Aumento da população urbana e surgimento de problemas sociais", "Crescimento das florestas", "Crescimento da agricultura"],
                        correct: 1
                    },
                    {
                        question: "O que é densidade demográfica?",
                        options: ["Número de rios por região", "Número de pessoas por km²", "Altura das montanhas", "Extensão do território"],
                        correct: 1
                    },
                    {
                        question: "Qual é a principal atividade econômica do Brasil no setor primário?",
                        options: ["Indústria", "Agricultura e pecuária", "Comércio internacional", "Tecnologia"],
                        correct: 1
                    },
                    {
                        question: "O que é desmatamento?",
                        options: ["Crescimento de florestas", "Corte de árvores e retirada da vegetação natural", "Construção de cidades", "Formação de rios"],
                        correct: 1
                    },
                    {
                        question: "O que são recursos hídricos?",
                        options: ["Florestas", "Água disponível em rios, lagos e aquíferos", "Minérios", "Solo fértil"],
                        correct: 1
                    },
                    {
                        question: "Qual é a diferença entre clima e tempo?",
                        options: ["Clima é momentâneo e tempo é longo", "Clima é longo e tempo é momentâneo", "Ambos são iguais", "Tempo depende de relevo"],
                        correct: 1
                    },
                    {
                        question: "O que é vegetação de cerrado?",
                        options: ["Floresta densa e úmida", "Campos com árvores baixas e arbustos, predominante no Brasil central", "Região polar", "Deserto"],
                        correct: 1
                    },
                    {
                        question: "O que é industrialização?",
                        options: ["Crescimento das florestas", "Desenvolvimento de fábricas e produção em larga escala", "Construção de rios", "Agricultura de subsistência"],
                        correct: 1
                    },
                    {
                        question: "Qual é a principal fonte de energia renovável?",
                        options: ["Petróleo", "Energia solar", "Carvão", "Gás natural"],
                        correct: 1
                    },
                    {
                        question: "O que é fronteira?",
                        options: ["Região central de um país", "Limite territorial entre dois países", "Área rural", "Região costeira"],
                        correct: 1
                    },
                    {
                        question: "O que é migração?",
                        options: ["Construção de cidades", "Deslocamento de pessoas de um lugar para outro", "Crescimento de rios", "Formação de montanhas"],
                        correct: 1
                    },
                    {
                        question: "O que é urbanização sustentável?",
                        options: ["Crescimento das cidades sem planejamento", "Crescimento das cidades com planejamento ambiental e social", "Crescimento das florestas", "Crescimento da agricultura"],
                        correct: 1
                    },
                    {
                        question: "O que é região metropolitana?",
                        options: ["Área rural", "Conjunto de cidades próximas que formam um núcleo urbano integrado", "Apenas a capital do estado", "Área desabitada"],
                        correct: 1
                    },
                    {
                        question: "O que são biomas?",
                        options: ["Tipos de solos", "Conjuntos de seres vivos e vegetação adaptados a um clima", "Rios e lagos", "Montanhas e planícies"],
                        correct: 1
                    }
                ],
                3: [
                    {
                        question: "O que é globalização econômica?",
                        options: ["Aumento da produção agrícola", "Integração e interdependência das economias mundiais", "Crescimento das cidades", "Exploração de florestas"],
                        correct: 1
                    },
                    {
                        question: "O que é bioma?",
                        options: ["Um tipo de solo", "Conjunto de fauna, flora e clima de uma região", "Rio ou lago", "Montanha ou planície"],
                        correct: 1
                    },
                    {
                        question: "Qual é a principal causa do aquecimento global?",
                        options: ["Uso de energias renováveis", "Emissão de gases de efeito estufa", "Crescimento das florestas", "Movimento das placas tectônicas"],
                        correct: 1
                    },
                    {
                        question: "O que é industrialização?",
                        options: ["Crescimento da população rural", "Desenvolvimento de fábricas e produção em larga escala", "Exploração de minérios", "Crescimento de cidades pequenas"],
                        correct: 1
                    },
                    {
                        question: "Qual é a importância dos rios para a população?",
                        options: ["Produção de petróleo", "Fornecimento de água, transporte e energia", "Criar fronteiras", "Crescimento das cidades"],
                        correct: 1
                    },
                    {
                        question: "O que é urbanização?",
                        options: ["Crescimento das cidades e concentração de pessoas", "Formação de florestas", "Produção agrícola", "Criação de rios artificiais"],
                        correct: 0
                    },
                    {
                        question: "Qual é a relação entre industrialização e poluição?",
                        options: ["Poluição diminui", "Poluição aumenta devido a fábricas e veículos", "Não há relação", "Poluição depende apenas do clima"],
                        correct: 1
                    },
                    {
                        question: "O que são recursos naturais renováveis?",
                        options: ["Água, solo e energia solar que podem ser reutilizados", "Petróleo e carvão", "Minérios", "Todos os tipos de energia"],
                        correct: 0
                    },
                    {
                        question: "O que são fronteiras naturais?",
                        options: ["Limites formados por rios, montanhas e lagos", "Limites políticos", "Áreas desabitadas", "Regiões metropolitanas"],
                        correct: 0
                    },
                    {
                        question: "O que é desertificação?",
                        options: ["Crescimento de florestas", "Degradação de áreas produtivas por ação humana ou clima", "Formação de rios", "Expansão urbana"],
                        correct: 1
                    },
                    {
                        question: "Qual é a diferença entre clima equatorial e tropical?",
                        options: ["Equatorial é frio, tropical é quente", "Equatorial é quente e úmido, tropical tem estação seca e chuvosa", "Ambos são iguais", "Tropical é frio, equatorial é quente"],
                        correct: 1
                    },
                    {
                        question: "O que é globalização cultural?",
                        options: ["Crescimento das cidades", "Disseminação de hábitos, costumes e ideias entre países", "Aumento de recursos naturais", "Exploração agrícola"],
                        correct: 1
                    },
                    {
                        question: "O que é degradação ambiental?",
                        options: ["Proteção das florestas", "Destruição do meio ambiente por ação humana", "Crescimento das cidades", "Exploração agrícola sustentável"],
                        correct: 1
                    },
                    {
                        question: "Qual é a importância da preservação dos biomas?",
                        options: ["Garantir recursos naturais e equilíbrio ambiental", "Aumentar cidades", "Produzir petróleo", "Criar fronteiras"],
                        correct: 0
                    },
                    {
                        question: "O que é urbanização sustentável?",
                        options: ["Crescimento desordenado das cidades", "Planejamento urbano que respeita o meio ambiente", "Construção de fábricas", "Aumento da população rural"],
                        correct: 1
                    }
                ]
            },
            ciencias: {
                1: [
                    {
                        question: "Qual é o principal astro do Sistema Solar?",
                        options: ["Lua", "Sol", "Marte", "Júpiter"],
                        correct: 1
                    },
                    {
                        question: "Qual é o estado físico da água no gelo?",
                        options: ["Líquido", "Gasoso", "Sólido", "Plasma"],
                        correct: 2
                    },
                    {
                        question: "O que usamos para respirar?",
                        options: ["Estômago", "Pulmões", "Coração", "Fígado"],
                        correct: 1
                    },
                    {
                        question: "Qual é o planeta mais próximo do Sol?",
                        options: ["Marte", "Mercúrio", "Terra", "Saturno"],
                        correct: 1
                    },
                    {
                        question: "Os seres vivos precisam de quê para sobreviver?",
                        options: ["Água e alimento", "Brinquedos", "Energia elétrica", "Luz artificial"],
                        correct: 0
                    },
                    {
                        question: "Qual é o órgão responsável por bombear o sangue?",
                        options: ["Pulmão", "Coração", "Fígado", "Estômago"],
                        correct: 1
                    },
                    {
                        question: "Qual dos seguintes é um animal vertebrado?",
                        options: ["Minhoca", "Peixe", "Inseto", "Caracol"],
                        correct: 1
                    },
                    {
                        question: "O que é fotossíntese?",
                        options: ["Respiração das plantas", "Processo em que a planta produz alimento", "Crescimento das raízes", "Polinização"],
                        correct: 1
                    },
                    {
                        question: "Qual é o gás essencial para a respiração?",
                        options: ["Oxigênio", "Gás carbônico", "Nitrogênio", "Hidrogênio"],
                        correct: 0
                    },
                    {
                        question: "O que é um ser vivo?",
                        options: ["Tudo que nasce, cresce, se reproduz e morre", "Somente os humanos", "Apenas os animais", "Coisas que se movem"],
                        correct: 0
                    },
                    {
                        question: "Onde os peixes vivem?",
                        options: ["No ar", "Na terra", "Na água", "No gelo"],
                        correct: 2
                    },
                    {
                        question: "O que protege o corpo humano de doenças?",
                        options: ["O coração", "O sistema imunológico", "Os ossos", "O sangue"],
                        correct: 1
                    },
                    {
                        question: "Qual o principal astro que ilumina a Terra à noite?",
                        options: ["Sol", "Vênus", "Lua", "Marte"],
                        correct: 2
                    },
                    {
                        question: "O que é necessário para uma planta viver?",
                        options: ["Água, luz e ar", "Fogo", "Som", "Ferro"],
                        correct: 0
                    },
                    {
                        question: "O que é um mamífero?",
                        options: ["Animal que bota ovos", "Animal que nasce do corpo da mãe e mama", "Animal que vive na água", "Animal que voa"],
                        correct: 1
                    }
                ],
                2: [
                    {
                        question: "O sangue circula no corpo através de qual sistema?",
                        options: ["Digestório", "Circulatório", "Respiratório", "Nervoso"],
                        correct: 1
                    },
                    {
                        question: "Qual é a função principal dos pulmões?",
                        options: ["Bombear sangue", "Absorver oxigênio", "Produzir energia", "Armazenar ar"],
                        correct: 1
                    },
                    {
                        question: "As plantas produzem seu próprio alimento por meio de qual processo?",
                        options: ["Germinação", "Fotossíntese", "Polinização", "Respiração"],
                        correct: 1
                    },
                    {
                        question: "Qual desses é um exemplo de decompositor?",
                        options: ["Árvore", "Fungos", "Gato", "Pássaro"],
                        correct: 1
                    },
                    {
                        question: "O que é o DNA?",
                        options: ["Um tipo de célula", "Material genético", "Nutriente", "Gás"],
                        correct: 1
                    },
                    {
                        question: "Qual é o principal gás produzido na fotossíntese?",
                        options: ["Gás carbônico", "Oxigênio", "Metano", "Hidrogênio"],
                        correct: 1
                    },
                    {
                        question: "O que é um ecossistema?",
                        options: ["Conjunto de seres vivos e ambiente", "Um tipo de célula", "Só o solo", "Apenas os animais"],
                        correct: 0
                    },
                    {
                        question: "O que é cadeia alimentar?",
                        options: ["Sequência de alimentação entre os seres vivos", "Lista de plantas", "Sistema respiratório", "Formação de células"],
                        correct: 0
                    },
                    {
                        question: "Qual é o órgão responsável pela digestão dos alimentos?",
                        options: ["Pulmões", "Estômago", "Coração", "Ossos"],
                        correct: 1
                    },
                    {
                        question: "Os seres vivos que produzem seu próprio alimento são chamados de:",
                        options: ["Consumidores", "Decompositores", "Produtores", "Predadores"],
                        correct: 2
                    },
                    {
                        question: "Qual o nome da camada que protege a Terra dos raios ultravioletas?",
                        options: ["Camada de ozônio", "Crosta terrestre", "Manto", "Atmosfera"],
                        correct: 0
                    },
                    {
                        question: "Qual é a principal fonte de energia da Terra?",
                        options: ["Sol", "Lua", "Petróleo", "Eletricidade"],
                        correct: 0
                    },
                    {
                        question: "O que é biodiversidade?",
                        options: ["Variedade de seres vivos", "Um tipo de planta", "O clima", "O solo"],
                        correct: 0
                    },
                    {
                        question: "Qual parte da célula controla suas atividades?",
                        options: ["Núcleo", "Citoplasma", "Parede celular", "Clorofila"],
                        correct: 0
                    },
                    {
                        question: "Qual é o processo que transforma a água líquida em vapor?",
                        options: ["Condensação", "Evaporação", "Solidificação", "Fusão"],
                        correct: 1
                    }
                ],
                3: [
                    {
                        question: "O que é fotossíntese?",
                        options: ["Processo em que os animais produzem energia", "Processo em que as plantas produzem alimento usando luz, água e CO₂", "Processo de respiração das plantas", "Processo de decomposição da matéria orgânica"],
                        correct: 1
                    },
                    {
                        question: "Qual é a função dos glóbulos vermelhos?",
                        options: ["Combater doenças", "Transportar oxigênio pelo corpo", "Produzir hormônios", "Armazenar nutrientes"],
                        correct: 1
                    },
                    {
                        question: "O que é um vírus?",
                        options: ["Um ser vivo que realiza todas as funções vitais sozinho", "Um agente infeccioso que precisa de uma célula hospedeira para se reproduzir", "Um tipo de bactéria", "Um fungo microscópico"],
                        correct: 1
                    },
                    {
                        question: "Qual é a função dos rins?",
                        options: ["Filtrar o sangue e produzir urina", "Bombear sangue", "Produzir enzimas digestivas", "Armazenar glicose"],
                        correct: 0
                    },
                    {
                        question: "O que caracteriza os animais invertebrados?",
                        options: ["Possuem coluna vertebral", "Não possuem coluna vertebral", "São todos aquáticos", "São todos vertebrados"],
                        correct: 1
                    },
                    {
                        question: "Qual é o principal papel dos decompositores?",
                        options: ["Produzir alimento para as plantas", "Transformar matéria orgânica morta em nutrientes para o solo", "Consumir produtores", "Polinizar plantas"],
                        correct: 1
                    },
                    {
                        question: "O que é respiração celular?",
                        options: ["Processo de obtenção de energia pelas células usando oxigênio", "Processo de produção de clorofila", "Fotossíntese", "Circulação do sangue"],
                        correct: 0
                    },
                    {
                        question: "Qual é a função do sistema nervoso?",
                        options: ["Produzir hormônios", "Controlar e coordenar as funções do corpo", "Filtrar o sangue", "Bombear sangue"],
                        correct: 1
                    },
                    {
                        question: "O que é homeostase?",
                        options: ["Capacidade do corpo de manter condições internas estáveis", "Crescimento de plantas", "Movimento dos planetas", "Digestão de alimentos"],
                        correct: 0
                    },
                    {
                        question: "Qual é a diferença entre vírus e bactéria?",
                        options: ["Vírus são maiores que bactérias", "Bactérias podem se reproduzir sozinhas; vírus precisam de células hospedeiras", "Bactérias não causam doenças", "Vírus possuem células"],
                        correct: 1
                    },
                    {
                        question: "O que é mutação genética?",
                        options: ["Alteração no DNA de um organismo", "Processo de fotossíntese", "Tipo de reprodução", "Ciclo da água"],
                        correct: 0
                    },
                    {
                        question: "Qual é a função dos hormônios?",
                        options: ["Transportar oxigênio", "Regular funções do corpo, como crescimento e metabolismo", "Decompor nutrientes", "Armazenar água"],
                        correct: 1
                    },
                    {
                        question: "O que é biodiversidade?",
                        options: ["A quantidade de água em um ecossistema", "Variedade de espécies, genes e ecossistemas", "População humana", "Tipo de solo"],
                        correct: 1
                    },
                    {
                        question: "Qual é a função dos cloroplastos?",
                        options: ["Produzir energia nas células animais", "Realizar fotossíntese nas células vegetais", "Controlar a célula", "Armazenar água"],
                        correct: 1
                    },
                    {
                        question: "O que é efeito estufa?",
                        options: ["Aquecimento da Terra causado pelo excesso de gases na atmosfera", "Resfriamento da Terra", "Processo de fotossíntese", "Movimento das placas tectônicas"],
                        correct: 0
                    }
                ]
            },
            ingles: {
                1: [
                    {
                        question: "How do you say 'casa' in English?",
                        options: ["Car", "House", "Home", "Room"],
                        correct: 1
                    },
                    {
                        question: "What is the plural of 'cat'?",
                        options: ["Cats", "Cat", "Cates", "Caties"],
                        correct: 0
                    },
                    {
                        question: "How do you say 'bom dia' in English?",
                        options: ["Good night", "Good morning", "Hello", "Good afternoon"],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: I _____ a student.",
                        options: ["is", "am", "are", "be"],
                        correct: 1
                    },
                    {
                        question: "What is the opposite of 'hot'?",
                        options: ["Cold", "Warm", "Tall", "Small"],
                        correct: 0
                    },
                    {
                        question: "How do you say 'maçã' in English?",
                        options: ["Banana", "Orange", "Apple", "Grapes"],
                        correct: 2
                    },
                    {
                        question: "Choose the correct question: _____ you like pizza?",
                        options: ["Are", "Do", "Is", "Does"],
                        correct: 1
                    },
                    {
                        question: "How do you say 'amigo' in English?",
                        options: ["Friend", "Teacher", "Father", "Brother"],
                        correct: 0
                    },
                    {
                        question: "Complete the sentence: She _____ my sister.",
                        options: ["is", "am", "are", "be"],
                        correct: 0
                    },
                    {
                        question: "What is the color of the sky on a sunny day?",
                        options: ["Green", "Blue", "Red", "Yellow"],
                        correct: 1
                    },
                    {
                        question: "How do you say 'livro' in English?",
                        options: ["Pen", "Book", "Notebook", "Paper"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct negative sentence: I _____ like chocolate.",
                        options: ["don't", "doesn't", "not", "no"],
                        correct: 0
                    },
                    {
                        question: "What is the plural of 'dog'?",
                        options: ["Dog", "Dogs", "Doges", "Dogies"],
                        correct: 1
                    },
                    {
                        question: "How do you say 'obrigado' in English?",
                        options: ["Thanks", "Sorry", "Please", "Hello"],
                        correct: 0
                    },
                    {
                        question: "Complete the sentence: They _____ in the park.",
                        options: ["is", "am", "are", "be"],
                        correct: 2
                    }
                ],
                2: [
                    {
                        question: "Complete the sentence: She _____ reading a book now.",
                        options: ["is", "are", "am", "be"],
                        correct: 0
                    },
                    {
                        question: "Choose the correct sentence:",
                        options: ["I am go to school.", "I am going to school.", "I going to school.", "I goes to school."],
                        correct: 1
                    },
                    {
                        question: "What is the past form of 'eat'?",
                        options: ["Eats", "Ate", "Eated", "Eating"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct translation: 'Eu fui ao parque ontem.'",
                        options: ["I go to the park yesterday.", "I went to the park yesterday.", "I am going to the park yesterday.", "I goes to the park yesterday."],
                        correct: 1
                    },
                    {
                        question: "How do you say 'chave' in English?",
                        options: ["Door", "Key", "Lock", "Window"],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: They _____ playing football now.",
                        options: ["is", "are", "am", "be"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct negative sentence: He _____ like apples.",
                        options: ["don't", "doesn't", "not", "no"],
                        correct: 1
                    },
                    {
                        question: "What is the opposite of 'difficult'?",
                        options: ["Hard", "Easy", "Complicated", "Strong"],
                        correct: 1
                    },
                    {
                        question: "Complete the question: _____ you like pizza?",
                        options: ["Are", "Do", "Does", "Is"],
                        correct: 1
                    },
                    {
                        question: "How do you say 'professor' in English?",
                        options: ["Teacher", "Student", "Friend", "Doctor"],
                        correct: 0
                    },
                    {
                        question: "Choose the correct past sentence: I _____ a movie yesterday.",
                        options: ["watch", "watched", "watching", "watches"],
                        correct: 1
                    },
                    {
                        question: "What is the plural of 'child'?",
                        options: ["Childs", "Children", "Childes", "Childrens"],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: We _____ having lunch now.",
                        options: ["is", "are", "am", "be"],
                        correct: 1
                    },
                    {
                        question: "How do you say 'gato' in English?",
                        options: ["Dog", "Cat", "Mouse", "Bird"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct sentence:",
                        options: ["She don't like chocolate.", "She doesn't like chocolate.", "She not like chocolate.", "She no like chocolate."],
                        correct: 1
                    }
                ],
                3: [
                    {
                        question: "Complete the sentence in passive voice: The book _____ by the teacher.",
                        options: ["is read", "reads", "was read", "readed"],
                        correct: 2
                    },
                    {
                        question: "Choose the correct sentence:",
                        options: ["She has visited Paris last year.", "She visited Paris last year.", "She visit Paris last year.", "She was visit Paris last year."],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: They _____ been to London twice.",
                        options: ["has", "have", "had", "is"],
                        correct: 1
                    },
                    {
                        question: "What is the past form of 'go'?",
                        options: ["Go", "Went", "Gone", "Goed"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct passive sentence: The letter _____ by Maria.",
                        options: ["is wrote", "was written", "wrote", "was write"],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: If I _____ rich, I would travel around the world.",
                        options: ["am", "were", "was", "be"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct reported speech: 'I am happy,' she said.",
                        options: ["She said she is happy.", "She said she was happy.", "She says she was happy.", "She said she happy."],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: By this time next year, I _____ my exams.",
                        options: ["will finish", "will have finished", "finish", "have finished"],
                        correct: 1
                    },
                    {
                        question: "What is the opposite of 'increase'?",
                        options: ["Rise", "Decrease", "Grow", "Improve"],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: The project _____ by the students last week.",
                        options: ["is completed", "was completed", "completes", "completed"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct sentence:",
                        options: ["I have seen him yesterday.", "I saw him yesterday.", "I have saw him yesterday.", "I seen him yesterday."],
                        correct: 1
                    },
                    {
                        question: "Complete the sentence: If she _____ earlier, she wouldn't have missed the bus.",
                        options: ["left", "had left", "leaves", "would leave"],
                        correct: 1
                    },
                    {
                        question: "Choose the correct vocabulary: The scientist made an important _____.",
                        options: ["discovery", "discover", "discovered", "discovering"],
                        correct: 0
                    },
                    {
                        question: "Complete the sentence: We _____ studying for three hours when the teacher arrived.",
                        options: ["are", "have been", "had been", "was"],
                        correct: 2
                    },
                    {
                        question: "Choose the correct sentence: The movie _____ by thousands of people.",
                        options: ["was watched", "watched", "was watching", "watches"],
                        correct: 0
                    }
                ]
            }
        };

        // Estado do quiz
        let currentState = {
            subject: null,
            level: null,
            currentQuestion: 0,
            score: 0,
            selectedOption: null,
            timer: null,
            timeLeft: 90, // 1 minuto e 30 segundos = 90 segundos
            showFeedback: false
        };

        // Elementos da DOM
        const screens = {
            subject: document.getElementById('subject-screen'),
            level: document.getElementById('level-screen'),
            question: document.getElementById('question-screen'),
            result: document.getElementById('result-screen')
        };

        // Sistema de Acessibilidade Expandido
        class AccessibilityManager {
            constructor() {
                this.currentFontSize = 'medium';
                this.currentContrast = 'normal';
                this.contrastSchemes = ['normal', 'black-white', 'yellow-black', 'blue-white', 'dark-mode'];
                this.init();
            }

            init() {
                this.setupFontSizeControls();
                this.setupContrastControls();
                this.setupKeyboardNavigation();
                this.loadPreferences();
            }

            setupFontSizeControls() {
                const fontButtons = document.querySelectorAll('.font-btn');
                fontButtons.forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        const size = e.target.getAttribute('data-size');
                        this.setFontSize(size);
                        
                        fontButtons.forEach(b => b.classList.remove('active'));
                        e.target.classList.add('active');
                    });
                });
            }

            setupContrastControls() {
                const contrastOptions = document.querySelectorAll('.contrast-option');
                contrastOptions.forEach(option => {
                    option.addEventListener('click', (e) => {
                        const contrast = e.currentTarget.getAttribute('data-contrast');
                        this.setContrast(contrast);
                        
                        contrastOptions.forEach(opt => opt.classList.remove('active'));
                        e.currentTarget.classList.add('active');
                    });
                });

                document.getElementById('contrast-toggle').addEventListener('click', () => {
                    this.cycleContrastSchemes();
                });
            }

            setFontSize(size) {
                document.body.classList.remove('font-small', 'font-medium', 'font-large', 'font-xlarge');
                document.body.classList.add(`font-${size}`);
                this.currentFontSize = size;
                localStorage.setItem('preferredFontSize', size);
            }

            setContrast(contrast) {
                this.contrastSchemes.forEach(scheme => {
                    document.body.classList.remove(`contrast-${scheme}`);
                });
                
                if (contrast !== 'normal') {
                    document.body.classList.add(`contrast-${contrast}`);
                }
                
                this.currentContrast = contrast;
                localStorage.setItem('preferredContrast', contrast);
            }

            cycleContrastSchemes() {
                const currentIndex = this.contrastSchemes.indexOf(this.currentContrast);
                const nextIndex = (currentIndex + 1) % this.contrastSchemes.length;
                const nextContrast = this.contrastSchemes[nextIndex];
                
                this.setContrast(nextContrast);
                
                const contrastOptions = document.querySelectorAll('.contrast-option');
                contrastOptions.forEach(opt => {
                    opt.classList.remove('active');
                    if (opt.getAttribute('data-contrast') === nextContrast) {
                        opt.classList.add('active');
                    }
                });
            }

            setupKeyboardNavigation() {
                document.addEventListener('keydown', (e) => {
                    if (e.ctrlKey) {
                        switch(e.key) {
                            case '1': this.setFontSize('small'); break;
                            case '2': this.setFontSize('medium'); break;
                            case '3': this.setFontSize('large'); break;
                            case '4': this.setFontSize('xlarge'); break;
                            case 'c': this.cycleContrastSchemes(); break;
                        }
                    }
                });
            }

            loadPreferences() {
                const savedFontSize = localStorage.getItem('preferredFontSize');
                const savedContrast = localStorage.getItem('preferredContrast');

                if (savedFontSize) {
                    this.setFontSize(savedFontSize);
                    document.querySelector(`.font-btn[data-size="${savedFontSize}"]`).classList.add('active');
                }

                if (savedContrast) {
                    this.setContrast(savedContrast);
                    document.querySelector(`.contrast-option[data-contrast="${savedContrast}"]`).classList.add('active');
                }
            }
        }

        // Inicializar gerenciador de acessibilidade
        const accessibility = new AccessibilityManager();

        // Funções do Quiz
        function showScreen(screen) {
            Object.values(screens).forEach(s => s.classList.remove('active'));
            screen.classList.add('active');
        }

        function formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;
            return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
        }

        function updateTimerDisplay() {
            const timerElement = document.getElementById('timer');
            timerElement.textContent = formatTime(currentState.timeLeft);
            
            // Atualizar classes de aviso
            timerElement.classList.remove('warning', 'danger');
            if (currentState.timeLeft <= 30) {
                timerElement.classList.add('danger');
            } else if (currentState.timeLeft <= 60) {
                timerElement.classList.add('warning');
            }
        }

        function resetTimer() {
            clearInterval(currentState.timer);
            currentState.timeLeft = 90; // 1 minuto e 30 segundos
            updateTimerDisplay();
            
            currentState.timer = setInterval(function() {
                currentState.timeLeft--;
                updateTimerDisplay();
                
                // Avisos de tempo
                if (currentState.timeLeft === 30) {
                    // Aviso visual já é feito pela classe danger
                }
                
                if (currentState.timeLeft === 10) {
                    // Últimos 10 segundos
                }
                
                if (currentState.timeLeft <= 0) {
                    clearInterval(currentState.timer);
                    if (!currentState.showFeedback) {
                        showAnswerFeedback();
                    }
                    setTimeout(nextQuestion, 2000);
                }
            }, 1000);
        }

        function startQuiz() {
            currentState.currentQuestion = 0;
            currentState.score = 0;
            currentState.showFeedback = false;
            showScreen(screens.question);
            loadQuestion();
        }

        function loadQuestion() {
            const questions = quizData[currentState.subject][currentState.level];
            const question = questions[currentState.currentQuestion];
            
            const progress = ((currentState.currentQuestion + 1) / questions.length) * 100;
            document.getElementById('progress-bar').style.width = `${progress}%`;
            
            document.getElementById('question-text').textContent = question.question;
            
            const optionsContainer = document.getElementById('options-container');
            optionsContainer.innerHTML = '';
            
            question.options.forEach((option, index) => {
                const optionElement = document.createElement('div');
                optionElement.className = 'option';
                optionElement.textContent = option;
                optionElement.setAttribute('data-index', index);
                optionElement.setAttribute('tabindex', '0');
                optionElement.setAttribute('role', 'button');
                
                optionElement.addEventListener('click', function() {
                    if (!currentState.showFeedback) {
                        selectOption(this);
                    }
                });
                
                optionsContainer.appendChild(optionElement);
            });
            
            currentState.selectedOption = null;
            currentState.showFeedback = false;
            resetTimer();
        }

        function selectOption(optionElement) {
            document.querySelectorAll('.option').forEach(opt => {
                opt.classList.remove('selected');
                opt.setAttribute('aria-selected', 'false');
            });
            
            optionElement.classList.add('selected');
            optionElement.setAttribute('aria-selected', 'true');
            currentState.selectedOption = parseInt(optionElement.getAttribute('data-index'));
            showAnswerFeedback();
        }

        function showAnswerFeedback() {
            currentState.showFeedback = true;
            const questions = quizData[currentState.subject][currentState.level];
            const question = questions[currentState.currentQuestion];
            const options = document.querySelectorAll('.option');
            
            options.forEach((option, index) => {
                if (index === question.correct) {
                    option.classList.add('correct');
                } else if (index === currentState.selectedOption && index !== question.correct) {
                    option.classList.add('incorrect');
                }
            });
            
            if (currentState.selectedOption === question.correct) {
                currentState.score++;
            }
        }

        function nextQuestion() {
            clearInterval(currentState.timer);
            
            const questions = quizData[currentState.subject][currentState.level];
            currentState.currentQuestion++;
            
            if (currentState.currentQuestion < questions.length) {
                loadQuestion();
            } else {
                showResults();
            }
        }

        function showResults() {
            const questions = quizData[currentState.subject][currentState.level];
            const scorePercentage = Math.round((currentState.score / questions.length) * 100);
            
            document.getElementById('score-circle').textContent = `${scorePercentage}%`;
            document.getElementById('correct-answers').textContent = currentState.score;
            document.getElementById('wrong-answers').textContent = questions.length - currentState.score;
            document.getElementById('total-questions').textContent = questions.length;
            
            let message = "";
            if (scorePercentage >= 90) {
                message = "Incrível! Seu conhecimento está brilhando! 🌟";
            } else if (scorePercentage >= 70) {
                message = "Muito bem! Você está no caminho certo! 💪";
            } else if (scorePercentage >= 50) {
                message = "Bom trabalho! Continue se dedicando! 📚";
            } else {
                message = "Toda jornada começa com um passo! Continue praticando! 🚀";
            }
            
            document.getElementById('result-message').textContent = message;
            showScreen(screens.result);
        }

        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Seleção de matéria
            document.querySelectorAll('.subject-card').forEach(card => {
                card.addEventListener('click', function() {
                    currentState.subject = this.getAttribute('data-subject');
                    document.getElementById('current-subject').textContent = 
                        this.querySelector('h3').textContent;
                    showScreen(screens.level);
                });
            });

            // Voltar para matérias
            document.getElementById('back-to-subjects').addEventListener('click', function() {
                showScreen(screens.subject);
            });

            // Voltar para níveis (da tela de perguntas)
            document.getElementById('back-to-levels').addEventListener('click', function() {
                clearInterval(currentState.timer);
                showScreen(screens.level);
            });

            // Voltar ao início (da tela de resultados)
            document.getElementById('back-to-subjects-final').addEventListener('click', function() {
                showScreen(screens.subject);
            });

            // Seleção de nível
            document.querySelectorAll('.level-card').forEach(card => {
                card.addEventListener('click', function() {
                    currentState.level = parseInt(this.getAttribute('data-level'));
                    document.getElementById('current-level').textContent = currentState.level;
                    startQuiz();
                });
            });

            // Próxima pergunta
            document.getElementById('next-question').addEventListener('click', function() {
                if (currentState.showFeedback) {
                    nextQuestion();
                } else if (currentState.selectedOption !== null) {
                    showAnswerFeedback();
                    setTimeout(nextQuestion, 1500);
                }
            });

            // Reiniciar quiz
            document.getElementById('restart-quiz').addEventListener('click', function() {
                showScreen(screens.subject);
            });
        });
    </script>
</body>
</html>