<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="estilo.css" />
  <title>Login - Study Click</title>
  
</head>
<body>
  <form action = "loginusuario.php" method = "POST">
  <div class="login-card">
    <p> "A língua é o nosso primeiro universo"</p>
    <img src= "logo.png" alt="Logo do Study Click">
    <h1>Login</h1>
    <input type="text" id="nome" name="nome" placeholder="Nome">
  <input type="password" id="senha" name="senha" placeholder="Senha">
    <button type="submit">Entrar</button>
    <?php
  if (isset ($_GET['msg'])){
    echo $_GET ['msg'];
  }
    ?>
      <div>
      <a href="cadastro.php"> Cadastrar-se</a>
      
  </div>
 
</body>
</html>