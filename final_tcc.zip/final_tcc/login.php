<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="estilo.css" />
  <title>Login - Study Click</title>
  
</head>
<body>
  <div class="login-card">
    <p> "A língua é o nosso primeiro universo"</p>
    <img src= "Logoatualizada.png" alt="Logo do Study Click">
    <h1>Login</h1>
    <input type="text" placeholder="Nome">
    <input type="password" placeholder="Senha">
    <button>Entrar</button>
    <?php
  if (isset ($_GET['msg'])){
    echo $_GET ['msg'];
  }
    ?>
      <div>
      <a href="cadastro.php"> Cadastrar-se</a>
      
  </div>
  <?php
    if (isset($_POST['usuario']) && isset($_POST['senha'])){
      include("conexao.php");

      $sql = "
      select from tbusuarios
      where usuario = '{$_POST['usuario']}'
      ";

      $resultado = mysqli_query($conexao,$sql);

      if(mysqli_num_rows($resultado) == 0){
        $erro = "usuario  não encontrado.";
          }else{
            $u = mysqli_fetch_assoc($resultado);

            if ()
          }
    }



?>
</body>
</html>